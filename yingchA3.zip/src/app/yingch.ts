export default class YingCh {
    studentId: Number;
    name: String;
    loginName: String;
    campus: String;
    picture: String;
    assignmentTitle: String;
}