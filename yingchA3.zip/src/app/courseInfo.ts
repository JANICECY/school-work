export default class Course {
    courseCode: Number;
    courseTitle: String;
    dayOfWeek: Number;
    profName: String;
}